import { useCallback } from 'react';

/**
 * useNotification Hook
 * Handles sound notifications and visual alerts
 * Features:
 * - Bip sound generation using Web Audio API
 * - Multiple notification types (success, alert, warning)
 * - Customizable frequency and duration
 */

export const useNotification = () => {
  const playBipSound = useCallback((frequency: number = 800, duration: number = 200) => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      oscillator.frequency.value = frequency;
      oscillator.type = 'sine';

      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + duration / 1000);

      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + duration / 1000);
    } catch (error) {
      console.log('Audio context not available');
    }
  }, []);

  const playSuccessNotification = useCallback(() => {
    // Double bip for success
    playBipSound(800, 150);
    setTimeout(() => playBipSound(1000, 150), 200);
  }, [playBipSound]);

  const playAlertNotification = useCallback(() => {
    // Triple bip for alert
    playBipSound(600, 100);
    setTimeout(() => playBipSound(600, 100), 150);
    setTimeout(() => playBipSound(600, 100), 300);
  }, [playBipSound]);

  const playWarningNotification = useCallback(() => {
    // Ascending bips for warning
    playBipSound(600, 150);
    setTimeout(() => playBipSound(800, 150), 200);
    setTimeout(() => playBipSound(1000, 150), 400);
  }, [playBipSound]);

  return {
    playBipSound,
    playSuccessNotification,
    playAlertNotification,
    playWarningNotification,
  };
};
