import { Mail, MessageCircle, User } from 'lucide-react';

/**
 * Contact Info Component - Cyberpunk Tactical Dashboard
 * Display Sibiya's bot contact information
 * Design: Neon contact card with email and WhatsApp links
 */

export default function ContactInfo() {
  const email = 'tsibiya874@gmail.com';
  const whatsapp = '0691893840';
  const whatsappLink = `https://wa.me/${whatsapp.replace(/\D/g, '')}`;

  return (
    <div className="flex flex-col gap-3">
      {/* Email Contact */}
      <a
        href={`mailto:${email}`}
        className="flex items-center gap-3 p-3 rounded-lg border border-accent/50 hover:border-accent transition-all duration-300 group"
        style={{
          background: 'linear-gradient(135deg, rgba(255, 0, 110, 0.05) 0%, rgba(0, 245, 255, 0.05) 100%)',
          boxShadow: 'none',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.boxShadow = '0 0 15px rgba(255, 0, 110, 0.4)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.boxShadow = 'none';
        }}>
        <Mail className="w-5 h-5 text-cyan-400 flex-shrink-0" />
        <div className="flex-1 min-w-0">
          <p className="text-xs text-accent/60 font-jetbrains-mono">EMAIL</p>
          <p className="text-sm text-accent font-jetbrains-mono truncate group-hover:text-cyan-400 transition-colors">
            {email}
          </p>
        </div>
      </a>

      {/* WhatsApp Contact */}
      <a
        href={whatsappLink}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-3 p-3 rounded-lg border border-accent/50 hover:border-accent transition-all duration-300 group"
        style={{
          background: 'linear-gradient(135deg, rgba(0, 245, 255, 0.05) 0%, rgba(255, 0, 110, 0.05) 100%)',
          boxShadow: 'none',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.boxShadow = '0 0 15px rgba(0, 245, 255, 0.4)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.boxShadow = 'none';
        }}>
        <MessageCircle className="w-5 h-5 text-cyan-400 flex-shrink-0" />
        <div className="flex-1 min-w-0">
          <p className="text-xs text-accent/60 font-jetbrains-mono">WHATSAPP</p>
          <p className="text-sm text-accent font-jetbrains-mono group-hover:text-cyan-400 transition-colors">
            {whatsapp}
          </p>
        </div>
      </a>

      {/* Creator Info */}
      <div className="flex items-center gap-3 p-3 rounded-lg border border-accent/30"
        style={{
          background: 'linear-gradient(135deg, rgba(255, 0, 110, 0.08) 0%, rgba(0, 245, 255, 0.08) 100%)',
        }}>
        <User className="w-5 h-5 text-accent flex-shrink-0" />
        <div className="flex-1 min-w-0">
          <p className="text-xs text-accent/60 font-jetbrains-mono">CREATOR</p>
          <p className="text-sm text-accent font-orbitron font-bold">SIBIYA'S BOT</p>
        </div>
      </div>
    </div>
  );
}
