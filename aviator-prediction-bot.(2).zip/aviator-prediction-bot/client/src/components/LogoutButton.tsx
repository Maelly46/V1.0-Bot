import { LogOut } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

/**
 * Logout Button Component - Cyberpunk Tactical Dashboard
 * Secure logout with confirmation
 */

export default function LogoutButton() {
  const { logout } = useAuth();

  const handleLogout = () => {
    if (window.confirm('Are you sure you want to logout?')) {
      logout();
    }
  };

  return (
    <button
      onClick={handleLogout}
      className="flex items-center gap-2 px-4 py-2 rounded-lg border border-accent/50 hover:border-accent transition-all duration-300 group"
      style={{
        background: 'linear-gradient(135deg, rgba(255, 0, 110, 0.05) 0%, rgba(0, 245, 255, 0.05) 100%)',
        boxShadow: 'none',
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.boxShadow = '0 0 15px rgba(255, 0, 110, 0.4)';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.boxShadow = 'none';
      }}>
      <LogOut className="w-4 h-4 text-accent group-hover:text-red-400 transition-colors" />
      <span className="text-sm font-orbitron font-bold text-accent group-hover:text-red-400 transition-colors tracking-wider">
        LOGOUT
      </span>
    </button>
  );
}
