import { useEffect, useState } from 'react';

/**
 * Digital Clock Component - Cyberpunk Tactical Dashboard
 * Real-time LED-style clock with market analysis timestamp
 * Design: Orbitron font with hot pink glow effect
 */

export default function DigitalClock() {
  const [time, setTime] = useState<string>('00:00:00');
  const [date, setDate] = useState<string>('');

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      const seconds = String(now.getSeconds()).padStart(2, '0');
      const dateStr = now.toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
      });

      setTime(`${hours}:${minutes}:${seconds}`);
      setDate(dateStr);
    };

    updateClock();
    const interval = setInterval(updateClock, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center gap-2 p-6 rounded-lg border-2 border-accent/50"
      style={{
        background: 'linear-gradient(135deg, rgba(10, 14, 39, 0.8) 0%, rgba(20, 25, 60, 0.8) 100%)',
        boxShadow: '0 0 20px rgba(255, 0, 110, 0.3), inset 0 0 20px rgba(0, 245, 255, 0.1)',
      }}>
      <div className="font-orbitron text-5xl font-bold text-accent tracking-wider"
        style={{
          textShadow: '0 0 10px rgba(255, 0, 110, 0.8), 0 0 20px rgba(255, 0, 110, 0.4)',
          fontFamily: 'Orbitron, monospace',
          letterSpacing: '0.15em',
        }}>
        {time}
      </div>
      <div className="font-jetbrains-mono text-sm text-accent/70 tracking-widest">
        {date}
      </div>
      <div className="text-xs text-accent/50 mt-2 font-jetbrains-mono">
        MARKET ANALYSIS ACTIVE
      </div>
    </div>
  );
}
