import { useState, useEffect } from 'react';
import { AlertCircle, TrendingUp, Clock } from 'lucide-react';

/**
 * Prediction Window Component - Cyberpunk Tactical Dashboard
 * Strategic betting windows: +2 (primary) and +10 (secondary)
 * Displays predicted time for next pink signal
 * Design: Glowing cards with hot pink borders and neon accents
 */

interface PredictionWindowProps {
  window: '+2' | '+10';
  isActive: boolean;
  confidence: number;
  multiplier: number;
  predictedTime?: string;
}

export default function PredictionWindow({
  window,
  isActive,
  confidence,
  multiplier,
  predictedTime,
}: PredictionWindowProps) {
  const [pulse, setPulse] = useState(false);

  useEffect(() => {
    if (!isActive) return;
    const interval = setInterval(() => setPulse(p => !p), 1000);
    return () => clearInterval(interval);
  }, [isActive]);

  const windowLabel = window === '+2' ? 'PRIMARY WINDOW' : 'SECONDARY WINDOW';
  const description = window === '+2'
    ? 'First betting opportunity'
    : 'Alternative betting window';

  return (
    <div
      className={`p-6 rounded-lg border-2 transition-all duration-300 ${
        isActive
          ? 'border-accent shadow-lg'
          : 'border-accent/30 opacity-60'
      }`}
      style={{
        background: `linear-gradient(135deg, rgba(${isActive ? '255, 0, 110' : '100, 50, 150'}, 0.1) 0%, rgba(${isActive ? '0, 245, 255' : '50, 100, 200'}, 0.05) 100%)`,
        boxShadow: isActive
          ? '0 0 30px rgba(255, 0, 110, 0.5), inset 0 0 20px rgba(0, 245, 255, 0.1)'
          : '0 0 10px rgba(255, 0, 110, 0.2)',
      }}>
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="font-orbitron text-xl font-bold text-accent tracking-wider">
            {window}
          </h3>
          <p className="text-xs text-accent/60 mt-1 font-jetbrains-mono">
            {windowLabel}
          </p>
        </div>
        {isActive && (
          <div className={`animate-pulse ${pulse ? 'opacity-100' : 'opacity-60'}`}>
            <AlertCircle className="w-6 h-6 text-accent" />
          </div>
        )}
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-accent/70 font-jetbrains-mono">
            CONFIDENCE
          </span>
          <div className="flex items-center gap-2">
            <div className="w-24 h-2 bg-accent/20 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-accent to-cyan-400 transition-all duration-300"
                style={{ width: `${confidence}%` }}
              />
            </div>
            <span className="text-sm font-bold text-accent font-jetbrains-mono">
              {confidence}%
            </span>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm text-accent/70 font-jetbrains-mono">
            MULTIPLIER
          </span>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-cyan-400" />
            <span className="text-lg font-bold text-cyan-400 font-jetbrains-mono">
              {multiplier.toFixed(2)}x
            </span>
          </div>
        </div>

        {predictedTime && (
          <div className="flex items-center justify-between pt-2 border-t border-accent/20">
            <span className="text-sm text-accent/70 font-jetbrains-mono">
              NEXT PINK SIGNAL
            </span>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-cyan-400" />
              <span className="text-sm font-bold text-cyan-400 font-jetbrains-mono">
                {predictedTime}
              </span>
            </div>
          </div>
        )}

        <div className="pt-3 border-t border-accent/20">
          <p className="text-xs text-accent/60 font-jetbrains-mono">
            {description}
          </p>
        </div>
      </div>

      {isActive && (
        <div className="mt-4 pt-4 border-t border-accent/20">
          <button className="w-full py-2 px-4 bg-gradient-to-r from-accent to-cyan-400 text-background font-bold rounded text-sm hover:shadow-lg transition-all duration-200"
            style={{
              boxShadow: '0 0 15px rgba(255, 0, 110, 0.5)',
            }}>
            PLACE BET
          </button>
        </div>
      )}
    </div>
  );
}
