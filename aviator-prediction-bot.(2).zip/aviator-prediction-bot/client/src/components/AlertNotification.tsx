import { useEffect, useState } from 'react';
import { AlertCircle } from 'lucide-react';

/**
 * AlertNotification Component
 * Displays glowing alert when predicted pink signal time matches
 * Features:
 * - Animated glowing effect
 * - Auto-dismiss after duration
 * - Electric theme styling
 */

interface AlertNotificationProps {
  message: string;
  type: 'success' | 'alert' | 'warning';
  duration?: number;
  onDismiss?: () => void;
}

export default function AlertNotification({
  message,
  type,
  duration = 5000,
  onDismiss,
}: AlertNotificationProps) {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      onDismiss?.();
    }, duration);

    return () => clearTimeout(timer);
  }, [duration, onDismiss]);

  if (!isVisible) return null;

  const typeStyles = {
    success: {
      bg: 'rgba(0, 245, 255, 0.1)',
      border: 'border-cyan-400',
      text: 'text-cyan-300',
      glow: '0 0 30px rgba(0, 245, 255, 0.8), inset 0 0 20px rgba(0, 245, 255, 0.3)',
      animation: 'animate-pulse',
    },
    alert: {
      bg: 'rgba(255, 0, 110, 0.1)',
      border: 'border-pink-500',
      text: 'text-pink-300',
      glow: '0 0 30px rgba(255, 0, 110, 0.8), inset 0 0 20px rgba(255, 0, 110, 0.3)',
      animation: 'animate-bounce',
    },
    warning: {
      bg: 'rgba(255, 200, 0, 0.1)',
      border: 'border-yellow-400',
      text: 'text-yellow-300',
      glow: '0 0 30px rgba(255, 200, 0, 0.8), inset 0 0 20px rgba(255, 200, 0, 0.3)',
      animation: 'animate-pulse',
    },
  };

  const style = typeStyles[type];

  return (
    <div
      className={`fixed top-8 right-8 z-50 ${style.animation}`}
      style={{
        animation: type === 'alert' ? 'bounce 0.5s infinite' : 'pulse 2s infinite',
      }}
    >
      <style>{`
        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.7; }
        }
      `}</style>
      
      <div
        className={`px-6 py-4 rounded-lg border-2 ${style.border} backdrop-blur-sm flex items-center gap-3`}
        style={{
          background: style.bg,
          boxShadow: style.glow,
        }}
      >
        <AlertCircle className={`w-6 h-6 ${style.text}`} />
        <div>
          <p className={`font-orbitron font-bold text-sm ${style.text} tracking-wider`}>
            {message}
          </p>
          <p className="text-xs text-white/50 font-jetbrains-mono mt-1">
            PINK SIGNAL DETECTED
          </p>
        </div>
      </div>
    </div>
  );
}
