import { useState, useEffect } from 'react';
import { TrendingDown, TrendingUp } from 'lucide-react';

/**
 * Data Tracker Component - Cyberpunk Tactical Dashboard
 * Historical game data and results tracking
 * Design: Scrollable list with platform-specific data
 */

interface GameResult {
  id: string;
  platform: 'Hollywood' | 'Betway' | 'LottoStar';
  multiplier: number;
  result: 'pink' | 'other';
  timestamp: Date;
}

export default function DataTracker() {
  const [results, setResults] = useState<GameResult[]>([]);

  useEffect(() => {
    // Initialize with sample data
    const sampleResults: GameResult[] = [
      {
        id: '1',
        platform: 'Hollywood',
        multiplier: 2.45,
        result: 'pink',
        timestamp: new Date(Date.now() - 5 * 60000),
      },
      {
        id: '2',
        platform: 'Betway',
        multiplier: 1.89,
        result: 'pink',
        timestamp: new Date(Date.now() - 10 * 60000),
      },
      {
        id: '3',
        platform: 'LottoStar',
        multiplier: 3.12,
        result: 'pink',
        timestamp: new Date(Date.now() - 15 * 60000),
      },
      {
        id: '4',
        platform: 'Hollywood',
        multiplier: 1.45,
        result: 'other',
        timestamp: new Date(Date.now() - 20 * 60000),
      },
      {
        id: '5',
        platform: 'Betway',
        multiplier: 2.78,
        result: 'pink',
        timestamp: new Date(Date.now() - 25 * 60000),
      },
    ];
    setResults(sampleResults);
  }, []);

  const addResult = (platform: 'Hollywood' | 'Betway' | 'LottoStar', multiplier: number, result: 'pink' | 'other') => {
    const newResult: GameResult = {
      id: Date.now().toString(),
      platform,
      multiplier,
      result,
      timestamp: new Date(),
    };
    setResults([newResult, ...results.slice(0, 9)]);
  };

  const platformStats = {
    Hollywood: results.filter(r => r.platform === 'Hollywood'),
    Betway: results.filter(r => r.platform === 'Betway'),
    LottoStar: results.filter(r => r.platform === 'LottoStar'),
  };

  const calculateStats = (platform: 'Hollywood' | 'Betway' | 'LottoStar') => {
    const platformResults = platformStats[platform];
    if (platformResults.length === 0) return { wins: 0, total: 0, winRate: 0 };
    const wins = platformResults.filter(r => r.result === 'pink').length;
    return {
      wins,
      total: platformResults.length,
      winRate: Math.round((wins / platformResults.length) * 100),
    };
  };

  return (
    <div className="space-y-4">
      {/* Platform Stats */}
      <div className="grid grid-cols-3 gap-3">
        {(['Hollywood', 'Betway', 'LottoStar'] as const).map(platform => {
          const stats = calculateStats(platform);
          return (
            <div
              key={platform}
              className="p-3 rounded-lg border border-accent/30"
              style={{
                background: 'linear-gradient(135deg, rgba(255, 0, 110, 0.05) 0%, rgba(0, 245, 255, 0.05) 100%)',
              }}>
              <p className="text-xs font-jetbrains-mono text-accent/60 mb-2">
                {platform.toUpperCase()}
              </p>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-lg font-bold text-accent font-orbitron">
                    {stats.wins}/{stats.total}
                  </p>
                  <p className="text-xs text-cyan-400 font-jetbrains-mono">
                    {stats.winRate}% WIN
                  </p>
                </div>
                {stats.winRate >= 50 ? (
                  <TrendingUp className="w-5 h-5 text-cyan-400" />
                ) : (
                  <TrendingDown className="w-5 h-5 text-accent/50" />
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Recent Results */}
      <div className="border border-accent/30 rounded-lg p-4"
        style={{
          background: 'linear-gradient(135deg, rgba(10, 14, 39, 0.5) 0%, rgba(20, 25, 60, 0.5) 100%)',
        }}>
        <h3 className="font-orbitron text-sm font-bold text-accent mb-3 tracking-wider">
          RECENT RESULTS
        </h3>
        <div className="space-y-2 max-h-64 overflow-y-auto">
          {results.length === 0 ? (
            <p className="text-xs text-accent/50 text-center py-4">
              No data yet. Start tracking results.
            </p>
          ) : (
            results.map(result => (
              <div
                key={result.id}
                className="flex items-center justify-between p-2 rounded border border-accent/20 text-xs font-jetbrains-mono"
                style={{
                  background: result.result === 'pink'
                    ? 'rgba(255, 0, 110, 0.1)'
                    : 'rgba(100, 100, 150, 0.1)',
                }}>
                <div className="flex-1">
                  <p className="text-accent/80">
                    {result.platform}
                  </p>
                  <p className="text-accent/50 text-xs">
                    {result.timestamp.toLocaleTimeString()}
                  </p>
                </div>
                <div className="text-right">
                  <p className={`font-bold ${result.result === 'pink' ? 'text-accent' : 'text-accent/50'}`}>
                    {result.multiplier.toFixed(2)}x
                  </p>
                  <p className={`text-xs ${result.result === 'pink' ? 'text-cyan-400' : 'text-accent/30'}`}>
                    {result.result === 'pink' ? 'PINK' : 'OTHER'}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Add Result Button */}
      <button
        onClick={() => {
          const platforms: ('Hollywood' | 'Betway' | 'LottoStar')[] = ['Hollywood', 'Betway', 'LottoStar'];
          const platform = platforms[Math.floor(Math.random() * platforms.length)];
          const multiplier = Math.random() * 3 + 1;
          const result = Math.random() > 0.3 ? 'pink' : 'other';
          addResult(platform, multiplier, result);
        }}
        className="w-full py-2 px-3 bg-gradient-to-r from-accent/20 to-cyan-400/20 border border-accent/50 rounded text-xs font-bold text-accent hover:border-accent transition-all duration-200">
        + ADD RESULT
      </button>
    </div>
  );
}
