import { useState } from 'react';

/**
 * Platform Tabs Component - Cyberpunk Tactical Dashboard
 * Select between Hollywood, Betway, and LottoStar platforms
 * Design: Neon tab buttons with active state highlighting
 */

type Platform = 'Hollywood' | 'Betway' | 'LottoStar';

interface PlatformTabsProps {
  onPlatformChange: (platform: Platform) => void;
  activePlatform: Platform;
}

/**
 * Platform Tabs Component - Cyberpunk Tactical Dashboard
 * Features:
 * - Three platform options: Hollywood, Betway, LottoStar
 * - Active state with enhanced neon glow and gradient
 * - Improved visibility with better contrast and shadows
 * - Responsive flex layout with proper spacing
 */
export default function PlatformTabs({
  onPlatformChange,
  activePlatform,
}: PlatformTabsProps) {
  const platforms: Platform[] = ['Hollywood', 'Betway', 'LottoStar'];

  return (
    <div className="flex gap-3 mb-6 flex-wrap">
      {platforms.map(platform => (
        <button
          key={platform}
          onClick={() => onPlatformChange(platform)}
          className={`px-6 py-3 rounded-lg font-orbitron font-bold text-sm tracking-wider transition-all duration-300 border-2 min-w-max ${
            activePlatform === platform
              ? 'border-accent text-accent'
              : 'border-accent/40 text-accent/70 hover:border-accent/70 hover:text-accent'
          }`}
          style={{
            background: activePlatform === platform
              ? 'linear-gradient(135deg, rgba(255, 0, 110, 0.3) 0%, rgba(0, 245, 255, 0.15) 100%)'
              : 'linear-gradient(135deg, rgba(255, 0, 110, 0.1) 0%, rgba(0, 245, 255, 0.08) 100%)',
            boxShadow: activePlatform === platform
              ? '0 0 25px rgba(255, 0, 110, 0.5), inset 0 0 15px rgba(0, 245, 255, 0.15)'
              : '0 0 10px rgba(255, 0, 110, 0.1)',
          }}>
          {platform.toUpperCase()}
        </button>
      ))}
    </div>
  );
}
