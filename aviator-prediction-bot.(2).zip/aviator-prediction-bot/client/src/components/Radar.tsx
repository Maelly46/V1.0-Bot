import { useEffect, useRef } from 'react';

/**
 * Radar Component - Cyberpunk Tactical Dashboard
 * Enhanced electric theme with fantastic animations
 * Features:
 * - Multiple rotating beams with electric pulses
 * - Glowing particles and energy effects
 * - Dynamic color transitions (pink to cyan)
 * - Radar sweep with trail effects
 * - Electric arc animations
 */

export default function Radar() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number | undefined>(undefined);
  const rotationRef = useRef<number>(0);
  const pulseRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const maxRadius = Math.min(centerX, centerY) - 10;

    // Particle system for electric effects
    const particles: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      life: number;
      maxLife: number;
      color: string;
    }> = [];

    const createParticles = (x: number, y: number, count: number) => {
      for (let i = 0; i < count; i++) {
        const angle = (Math.random() * Math.PI * 2);
        const speed = Math.random() * 2 + 1;
        particles.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          life: 1,
          maxLife: Math.random() * 0.5 + 0.3,
          color: Math.random() > 0.5 ? 'rgba(255, 0, 110, ' : 'rgba(0, 245, 255, ',
        });
      }
    };

    const drawRadar = () => {
      // Clear canvas with dark background and slight trail
      ctx.fillStyle = 'rgba(10, 14, 39, 0.15)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw enhanced concentric circles with glow
      const circles = [
        { radius: maxRadius * 0.25, color: 'rgba(255, 0, 110, 0.4)', width: 2 },
        { radius: maxRadius * 0.5, color: 'rgba(0, 245, 255, 0.4)', width: 2 },
        { radius: maxRadius * 0.75, color: 'rgba(255, 0, 110, 0.4)', width: 2 },
        { radius: maxRadius, color: 'rgba(0, 245, 255, 0.6)', width: 3 },
      ];

      circles.forEach(({ radius, color, width }) => {
        // Draw glow effect
        ctx.strokeStyle = color.replace('0.', '0.1');
        ctx.lineWidth = width + 4;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        ctx.stroke();

        // Draw main circle
        ctx.strokeStyle = color;
        ctx.lineWidth = width;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        ctx.stroke();
      });

      // Draw enhanced crosshairs with electric effect
      const crosshairAlpha = 0.4 + Math.sin(pulseRef.current * 0.05) * 0.2;
      ctx.strokeStyle = `rgba(255, 0, 110, ${crosshairAlpha})`;
      ctx.lineWidth = 1.5;
      ctx.setLineDash([5, 5]);
      ctx.beginPath();
      ctx.moveTo(centerX - maxRadius, centerY);
      ctx.lineTo(centerX + maxRadius, centerY);
      ctx.moveTo(centerX, centerY - maxRadius);
      ctx.lineTo(centerX, centerY + maxRadius);
      ctx.stroke();
      ctx.setLineDash([]);

      // Draw cardinal direction dots with pulsing effect
      const directions = [
        { x: centerX, y: centerY - maxRadius, label: 'N' },
        { x: centerX + maxRadius, y: centerY, label: 'E' },
        { x: centerX, y: centerY + maxRadius, label: 'S' },
        { x: centerX - maxRadius, y: centerY, label: 'W' },
      ];

      const dotPulse = 4 + Math.sin(pulseRef.current * 0.08) * 2;
      directions.forEach(({ x, y }) => {
        // Outer glow
        ctx.fillStyle = 'rgba(255, 0, 110, 0.3)';
        ctx.beginPath();
        ctx.arc(x, y, dotPulse + 3, 0, Math.PI * 2);
        ctx.fill();

        // Main dot
        ctx.fillStyle = 'rgba(255, 0, 110, 0.9)';
        ctx.beginPath();
        ctx.arc(x, y, dotPulse, 0, Math.PI * 2);
        ctx.fill();
      });

      // Draw primary scanning beam with electric effect
      const beamLength = maxRadius * 0.9;
      const beamAngle = (rotationRef.current * Math.PI) / 180;

      // Create electric arc effect
      const arcCount = 5;
      for (let i = 0; i < arcCount; i++) {
        const offset = (i / arcCount) * 0.3;
        const gradient = ctx.createLinearGradient(
          centerX,
          centerY,
          centerX + Math.cos(beamAngle + offset) * beamLength,
          centerY + Math.sin(beamAngle + offset) * beamLength
        );
        gradient.addColorStop(0, 'rgba(255, 0, 110, 0.6)');
        gradient.addColorStop(0.3, 'rgba(255, 0, 110, 0.3)');
        gradient.addColorStop(1, 'rgba(0, 245, 255, 0)');

        ctx.strokeStyle = gradient;
        ctx.lineWidth = 2 + i * 0.5;
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(
          centerX + Math.cos(beamAngle + offset) * beamLength,
          centerY + Math.sin(beamAngle + offset) * beamLength
        );
        ctx.stroke();
      }

      // Draw secondary beam (trailing effect)
      const secondaryAngle = ((rotationRef.current - 90) * Math.PI) / 180;
      const secondaryGradient = ctx.createLinearGradient(
        centerX,
        centerY,
        centerX + Math.cos(secondaryAngle) * beamLength,
        centerY + Math.sin(secondaryAngle) * beamLength
      );
      secondaryGradient.addColorStop(0, 'rgba(0, 245, 255, 0.4)');
      secondaryGradient.addColorStop(0.5, 'rgba(0, 245, 255, 0.1)');
      secondaryGradient.addColorStop(1, 'rgba(0, 245, 255, 0)');

      ctx.strokeStyle = secondaryGradient;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.lineTo(
        centerX + Math.cos(secondaryAngle) * beamLength * 0.7,
        centerY + Math.sin(secondaryAngle) * beamLength * 0.7
      );
      ctx.stroke();

      // Update and draw particles
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.life -= 0.02;

        if (p.life <= 0) {
          particles.splice(i, 1);
        } else {
          const alpha = p.life / p.maxLife;
          ctx.fillStyle = p.color + alpha + ')';
          ctx.beginPath();
          ctx.arc(p.x, p.y, 2, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Create particles at beam endpoint
      if (rotationRef.current % 10 === 0) {
        const beamX = centerX + Math.cos(beamAngle) * beamLength;
        const beamY = centerY + Math.sin(beamAngle) * beamLength;
        createParticles(beamX, beamY, 3);
      }

      // Draw center dot with enhanced glow
      const centerGlow = 10 + Math.sin(pulseRef.current * 0.1) * 3;
      ctx.fillStyle = 'rgba(0, 245, 255, 0.3)';
      ctx.beginPath();
      ctx.arc(centerX, centerY, centerGlow, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = 'rgba(0, 245, 255, 0.6)';
      ctx.beginPath();
      ctx.arc(centerX, centerY, centerGlow * 0.6, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = 'rgba(255, 0, 110, 1)';
      ctx.beginPath();
      ctx.arc(centerX, centerY, 4, 0, Math.PI * 2);
      ctx.fill();

      // Draw electric arcs around center
      const arcRadius = 15;
      const arcAngle = (pulseRef.current * 0.05) % (Math.PI * 2);
      ctx.strokeStyle = 'rgba(255, 0, 110, 0.6)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(centerX, centerY, arcRadius, arcAngle, arcAngle + Math.PI * 0.5);
      ctx.stroke();

      ctx.strokeStyle = 'rgba(0, 245, 255, 0.4)';
      ctx.beginPath();
      ctx.arc(centerX, centerY, arcRadius, arcAngle + Math.PI, arcAngle + Math.PI * 1.5);
      ctx.stroke();

      rotationRef.current = (rotationRef.current + 3) % 360;
      pulseRef.current += 1;
      animationRef.current = requestAnimationFrame(drawRadar);
    };

    drawRadar();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  return (
    <div className="flex flex-col items-center justify-center">
      <canvas
        ref={canvasRef}
        width={300}
        height={300}
        className="border-2 border-accent rounded-full shadow-lg"
        style={{
          boxShadow: '0 0 40px rgba(255, 0, 110, 0.7), 0 0 80px rgba(0, 245, 255, 0.3), inset 0 0 40px rgba(255, 0, 110, 0.2)',
        }}
      />
      <div className="mt-4 text-center">
        <p className="text-accent font-orbitron font-bold text-sm tracking-wider animate-pulse">
          ⚡ TACTICAL RADAR ⚡
        </p>
        <p className="text-cyan-400 font-jetbrains-mono text-xs mt-1 tracking-widest">
          ELECTRIC SCAN ACTIVE
        </p>
      </div>
    </div>
  );
}
