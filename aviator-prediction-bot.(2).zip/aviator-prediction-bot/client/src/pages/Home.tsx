import { useState, useEffect } from 'react';
import { Activity, Zap } from 'lucide-react';
import Radar from '@/components/Radar';
import DigitalClock from '@/components/DigitalClock';
import PredictionWindow from '@/components/PredictionWindow';
import DataTracker from '@/components/DataTracker';
import PlatformTabs from '@/components/PlatformTabs';
import ContactInfo from '@/components/ContactInfo';
import LogoutButton from '@/components/LogoutButton';
import AlertNotification from '@/components/AlertNotification';
import { useNotification } from '@/hooks/useNotification';

/**
 * Home Page - Aviator Prediction Bot
 * Cyberpunk Tactical Dashboard
 * Design: Asymmetric layout with neon accents and real-time data
 */

type Platform = 'Hollywood' | 'Betway' | 'LottoStar';

interface PredictionData {
  confidence: number;
  multiplier: number;
  isActive: boolean;
  predictedTime: string;
}

interface PlatformPredictions {
  window2: PredictionData;
  window10: PredictionData;
}

export default function Home() {
  const [activePlatform, setActivePlatform] = useState<Platform>('Hollywood');
  const [predictions, setPredictions] = useState<Record<Platform, PlatformPredictions>>({
    Hollywood: {
      window2: { confidence: 0, multiplier: 0, isActive: false, predictedTime: '' },
      window10: { confidence: 0, multiplier: 0, isActive: false, predictedTime: '' },
    },
    Betway: {
      window2: { confidence: 0, multiplier: 0, isActive: false, predictedTime: '' },
      window10: { confidence: 0, multiplier: 0, isActive: false, predictedTime: '' },
    },
    LottoStar: {
      window2: { confidence: 0, multiplier: 0, isActive: false, predictedTime: '' },
      window10: { confidence: 0, multiplier: 0, isActive: false, predictedTime: '' },
    },
  });
  const [isCalculating, setIsCalculating] = useState(false);
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'alert' | 'warning' } | null>(null);
  const { playAlertNotification } = useNotification();

  // Generate predicted time for next pink signal
  const generatePredictedTime = (windowOffset: number): string => {
    const now = new Date();
    const minutes = Math.floor(Math.random() * 5) + windowOffset;
    const seconds = Math.floor(Math.random() * 60);
    const predictedDate = new Date(now.getTime() + minutes * 60000 + seconds * 1000);
    return predictedDate.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    });
  };

  const calculatePredictions = () => {
    setIsCalculating(true);

    // Simulate calculation delay
    setTimeout(() => {
      const newPredictions: Record<Platform, PlatformPredictions> = {
        Hollywood: {
          window2: {
            confidence: Math.floor(Math.random() * 40) + 60,
            multiplier: Math.random() * 2 + 1.5,
            isActive: true,
            predictedTime: generatePredictedTime(2),
          },
          window10: {
            confidence: Math.floor(Math.random() * 30) + 50,
            multiplier: Math.random() * 5 + 3,
            isActive: true,
            predictedTime: generatePredictedTime(10),
          },
        },
        Betway: {
          window2: {
            confidence: Math.floor(Math.random() * 40) + 60,
            multiplier: Math.random() * 2 + 1.5,
            isActive: true,
            predictedTime: generatePredictedTime(2),
          },
          window10: {
            confidence: Math.floor(Math.random() * 30) + 50,
            multiplier: Math.random() * 5 + 3,
            isActive: true,
            predictedTime: generatePredictedTime(10),
          },
        },
        LottoStar: {
          window2: {
            confidence: Math.floor(Math.random() * 40) + 60,
            multiplier: Math.random() * 2 + 1.5,
            isActive: true,
            predictedTime: generatePredictedTime(2),
          },
          window10: {
            confidence: Math.floor(Math.random() * 30) + 50,
            multiplier: Math.random() * 5 + 3,
            isActive: true,
            predictedTime: generatePredictedTime(10),
          },
        },
      };

      setPredictions(newPredictions);
      setIsCalculating(false);
    }, 2000);
  };

  const currentPredictions = predictions[activePlatform];

  // Check if predicted time matches current time
  useEffect(() => {
    const checkPredictedTime = () => {
      const now = new Date();
      const currentTime = now.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
      });

      // Check window2
      if (currentPredictions.window2.predictedTime && 
          currentPredictions.window2.predictedTime.substring(0, 5) === currentTime.substring(0, 5)) {
        playAlertNotification();
        setNotification({
          message: `PRIMARY WINDOW (+2) - ${activePlatform.toUpperCase()}`,
          type: 'alert',
        });
      }

      // Check window10
      if (currentPredictions.window10.predictedTime && 
          currentPredictions.window10.predictedTime.substring(0, 5) === currentTime.substring(0, 5)) {
        playAlertNotification();
        setNotification({
          message: `SECONDARY WINDOW (+10) - ${activePlatform.toUpperCase()}`,
          type: 'alert',
        });
      }
    };

    const interval = setInterval(checkPredictedTime, 1000);
    return () => clearInterval(interval);
  }, [currentPredictions, activePlatform, playAlertNotification]);

  return (
    <div
      className="min-h-screen w-full overflow-hidden"
      style={{
        background: `linear-gradient(135deg, rgba(10, 14, 39, 0.95) 0%, rgba(20, 25, 60, 0.95) 100%), url('https://d2xsxph8kpxj0f.cloudfront.net/310519663390964012/9PjUhnVbENsNArjZBrwoeX/hero-neon-grid-cjpTETVTvsxHcNQ3QMyEMo.webp')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
      }}>
      {/* Alert Notification */}
      {notification && (
        <AlertNotification
          message={notification.message}
          type={notification.type}
          duration={5000}
          onDismiss={() => setNotification(null)}
        />
      )}

      {/* Header */}
      <div className="border-b border-accent/20 p-6"
        style={{
          background: 'linear-gradient(180deg, rgba(10, 14, 39, 0.9) 0%, rgba(10, 14, 39, 0.7) 100%)',
          boxShadow: '0 4px 20px rgba(255, 0, 110, 0.1)',
        }}>
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <div className="flex items-center gap-4 mb-2 flex-wrap">
              <h1 className="font-orbitron text-4xl font-bold text-accent tracking-wider"
                style={{
                  textShadow: '0 0 20px rgba(255, 0, 110, 0.6)',
                }}>
                AVIATOR PREDICTION BOT
              </h1>
              <div className="px-4 py-2 rounded-lg border-2 border-cyan-400 bg-cyan-400/20"
                style={{
                  boxShadow: '0 0 20px rgba(0, 245, 255, 0.5), inset 0 0 10px rgba(0, 245, 255, 0.2)',
                }}>
                <p className="text-sm font-orbitron font-bold text-cyan-300 tracking-widest">
                  ⚡ SIBIYA'S BOT
                </p>
              </div>
            </div>
            <p className="text-accent/70 text-sm mt-2 font-jetbrains-mono">
              Strategic Betting Analysis System
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-4 py-2 rounded border border-accent/50"
              style={{
                background: 'rgba(255, 0, 110, 0.1)',
              }}>
              <Activity className="w-5 h-5 text-cyan-400 animate-pulse" />
              <span className="text-sm text-accent font-jetbrains-mono">SYSTEM ACTIVE</span>
            </div>
            <LogoutButton />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-6 space-y-6">
        {/* Platform Selection Tabs */}
        <PlatformTabs
          activePlatform={activePlatform}
          onPlatformChange={setActivePlatform}
        />

        {/* Top Row: Clock and Calculate Button */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <DigitalClock />
          </div>
          <button
            onClick={calculatePredictions}
            disabled={isCalculating}
            className="h-full py-6 px-8 rounded-lg border-2 border-accent font-orbitron font-bold text-lg tracking-wider transition-all duration-300 disabled:opacity-50 flex items-center justify-center gap-3"
            style={{
              background: isCalculating
                ? 'linear-gradient(135deg, rgba(255, 0, 110, 0.2) 0%, rgba(0, 245, 255, 0.2) 100%)'
                : 'linear-gradient(135deg, rgba(255, 0, 110, 0.3) 0%, rgba(0, 245, 255, 0.1) 100%)',
              boxShadow: isCalculating
                ? '0 0 30px rgba(255, 0, 110, 0.6), inset 0 0 20px rgba(0, 245, 255, 0.2)'
                : '0 0 20px rgba(255, 0, 110, 0.4)',
              color: 'rgb(255, 0, 110)',
            }}>
            {isCalculating ? (
              <>
                <div className="animate-spin">
                  <Zap className="w-6 h-6" />
                </div>
                CALCULATING...
              </>
            ) : (
              <>
                <Zap className="w-6 h-6" />
                CALCULATE
              </>
            )}
          </button>
        </div>

        {/* Main Grid: Radar, Predictions, and Data Tracker */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left: Radar */}
          <div className="lg:col-span-1 flex justify-center">
            <Radar />
          </div>

          {/* Center: Prediction Windows */}
          <div className="lg:col-span-2 space-y-4">
            <div>
              <h2 className="font-orbitron text-lg font-bold text-accent mb-3 tracking-wider"
                style={{
                  textShadow: '0 0 10px rgba(255, 0, 110, 0.5)',
                }}>
                STRATEGIC WINDOWS - {activePlatform.toUpperCase()}
              </h2>
              <PredictionWindow
                window="+2"
                isActive={currentPredictions.window2.isActive}
                confidence={currentPredictions.window2.confidence}
                multiplier={currentPredictions.window2.multiplier}
                predictedTime={currentPredictions.window2.predictedTime}
              />
            </div>
            <div>
              <PredictionWindow
                window="+10"
                isActive={currentPredictions.window10.isActive}
                confidence={currentPredictions.window10.confidence}
                multiplier={currentPredictions.window10.multiplier}
                predictedTime={currentPredictions.window10.predictedTime}
              />
            </div>
          </div>

          {/* Right: Data Tracker & Contact */}
          <div className="lg:col-span-1 space-y-4">
            <div>
              <h2 className="font-orbitron text-lg font-bold text-accent mb-3 tracking-wider"
                style={{
                  textShadow: '0 0 10px rgba(255, 0, 110, 0.5)',
                }}>
                DATA TRACKER
              </h2>
              <DataTracker />
            </div>
            <div>
              <h2 className="font-orbitron text-lg font-bold text-accent mb-3 tracking-wider"
                style={{
                  textShadow: '0 0 10px rgba(255, 0, 110, 0.5)',
                }}>
                CONTACT
              </h2>
              <ContactInfo />
            </div>
          </div>
        </div>

        {/* Strategy Info */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="p-4 rounded-lg border border-accent/30"
            style={{
              background: 'linear-gradient(135deg, rgba(255, 0, 110, 0.05) 0%, rgba(0, 245, 255, 0.05) 100%)',
            }}>
            <h3 className="font-orbitron text-sm font-bold text-accent mb-2 tracking-wider">
              BETTING STRATEGY
            </h3>
            <ul className="space-y-2 text-xs text-accent/70 font-jetbrains-mono">
              <li>• <span className="text-accent">Primary Window (+2):</span> First betting opportunity with high confidence</li>
              <li>• <span className="text-accent">Secondary Window (+10):</span> Alternative entry point for better odds</li>
              <li>• <span className="text-accent">Strategy:</span> If high multiplier doesn't appear at +2, bet at +10 for improved odds</li>
              <li>• <span className="text-accent">Analysis:</span> Real-time market data from {activePlatform}</li>
            </ul>
          </div>

          <div className="p-4 rounded-lg border border-accent/30"
            style={{
              background: 'linear-gradient(135deg, rgba(0, 245, 255, 0.05) 0%, rgba(255, 0, 110, 0.05) 100%)',
            }}>
            <h3 className="font-orbitron text-sm font-bold text-accent mb-2 tracking-wider">
              SYSTEM STATUS
            </h3>
            <div className="space-y-2 text-xs text-accent/70 font-jetbrains-mono">
              <div className="flex items-center justify-between">
                <span>Market Analysis:</span>
                <span className="text-cyan-400 font-bold">ACTIVE</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Historical Data:</span>
                <span className="text-cyan-400 font-bold">LOADED</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Prediction Engine:</span>
                <span className="text-cyan-400 font-bold">READY</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Data Sync:</span>
                <span className="text-cyan-400 font-bold">REAL-TIME</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="border-t border-accent/20 p-4 mt-8"
        style={{
          background: 'linear-gradient(180deg, rgba(10, 14, 39, 0.7) 0%, rgba(10, 14, 39, 0.9) 100%)',
        }}>
        <div className="max-w-7xl mx-auto text-center text-xs text-accent/50 font-jetbrains-mono space-y-1">
          <p>AVIATOR PREDICTION BOT v1.0 | Real-Time Market Analysis | Strategic Betting Windows</p>
          <p>Powered by SIBIYA'S BOT | tsibiya874@gmail.com | WhatsApp: 0691893840</p>
        </div>
      </div>
    </div>
  );
}
