import { useState } from 'react';
import { Lock, Zap } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

/**
 * Login Page - Aviator Prediction Bot
 * Cyberpunk Tactical Dashboard - Authentication
 * Design: Neon login form with password security
 */

export default function Login() {
  const { login } = useAuth();
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simulate authentication delay
    setTimeout(() => {
      if (password.trim()) {
        try {
          login(password);
        } catch (err) {
          setError('Invalid password. Try again.');
        }
      } else {
        setError('Please enter a password');
      }
      setIsLoading(false);
    }, 800);
  };

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center overflow-hidden"
      style={{
        background: `linear-gradient(135deg, rgba(10, 14, 39, 0.95) 0%, rgba(20, 25, 60, 0.95) 100%), url('https://d2xsxph8kpxj0f.cloudfront.net/310519663390964012/9PjUhnVbENsNArjZBrwoeX/hero-neon-grid-cjpTETVTvsxHcNQ3QMyEMo.webp')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
      }}>
      {/* Animated Grid Background */}
      <div className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `linear-gradient(0deg, transparent 24%, rgba(255, 0, 110, 0.3) 25%, rgba(255, 0, 110, 0.3) 26%, transparent 27%, transparent 74%, rgba(255, 0, 110, 0.3) 75%, rgba(255, 0, 110, 0.3) 76%, transparent 77%, transparent),
                           linear-gradient(90deg, transparent 24%, rgba(0, 245, 255, 0.3) 25%, rgba(0, 245, 255, 0.3) 26%, transparent 27%, transparent 74%, rgba(0, 245, 255, 0.3) 75%, rgba(0, 245, 255, 0.3) 76%, transparent 77%, transparent)`,
          backgroundSize: '50px 50px',
        }} />

      {/* Login Container */}
      <div className="relative z-10 w-full max-w-md px-6">
        <div
          className="p-8 rounded-lg border-2 border-accent backdrop-blur-sm"
          style={{
            background: 'linear-gradient(135deg, rgba(10, 14, 39, 0.9) 0%, rgba(20, 25, 60, 0.9) 100%)',
            boxShadow: '0 0 50px rgba(255, 0, 110, 0.5), inset 0 0 30px rgba(0, 245, 255, 0.1)',
          }}>
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Zap className="w-8 h-8 text-cyan-400" />
              <h1 className="font-orbitron text-3xl font-bold text-accent tracking-wider"
                style={{
                  textShadow: '0 0 20px rgba(255, 0, 110, 0.6)',
                }}>
                SIBIYA'S BOT
              </h1>
            </div>
            <p className="text-accent/60 text-sm font-jetbrains-mono">
              AVIATOR PREDICTION SYSTEM
            </p>
            <p className="text-accent/40 text-xs mt-2 font-jetbrains-mono">
              SECURE ACCESS REQUIRED
            </p>
          </div>

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Password Input */}
            <div>
              <label className="block text-sm font-jetbrains-mono text-accent/70 mb-2">
                ACCESS PASSWORD
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-5 h-5 text-cyan-400 pointer-events-none" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError('');
                  }}
                  placeholder="Enter password"
                  className="w-full pl-10 pr-4 py-3 bg-background/50 border border-accent/50 rounded-lg text-accent placeholder-accent/30 font-jetbrains-mono focus:outline-none focus:border-accent focus:ring-2 focus:ring-accent/30 transition-all duration-300"
                  style={{
                    boxShadow: 'inset 0 0 10px rgba(0, 245, 255, 0.1)',
                  }}
                  disabled={isLoading}
                />
              </div>
            </div>

            {/* Error Message */}
            {error && (
              <div className="p-3 rounded-lg bg-red-500/20 border border-red-500/50"
                style={{
                  boxShadow: '0 0 10px rgba(239, 68, 68, 0.3)',
                }}>
                <p className="text-sm text-red-400 font-jetbrains-mono">
                  {error}
                </p>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 px-4 bg-gradient-to-r from-accent to-cyan-400 text-background font-orbitron font-bold rounded-lg tracking-wider transition-all duration-300 disabled:opacity-50 flex items-center justify-center gap-2"
              style={{
                boxShadow: '0 0 20px rgba(255, 0, 110, 0.5)',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.boxShadow = '0 0 30px rgba(255, 0, 110, 0.7)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.boxShadow = '0 0 20px rgba(255, 0, 110, 0.5)';
              }}>
              {isLoading ? (
                <>
                  <div className="animate-spin">
                    <Zap className="w-5 h-5" />
                  </div>
                  AUTHENTICATING...
                </>
              ) : (
                <>
                  <Lock className="w-5 h-5" />
                  UNLOCK SYSTEM
                </>
              )}
            </button>
          </form>

          {/* Info Text */}
          <div className="mt-6 pt-6 border-t border-accent/20">
            <p className="text-xs text-accent/50 font-jetbrains-mono text-center">
              Demo Password: <span className="text-accent/70 font-bold">sibiya123</span>
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-8">
          <p className="text-xs text-accent/40 font-jetbrains-mono">
            SIBIYA'S BOT | SECURE TACTICAL DASHBOARD
          </p>
        </div>
      </div>
    </div>
  );
}
