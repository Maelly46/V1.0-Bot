# Aviator Prediction Bot - Strategic Betting Analysis System

A cyberpunk-themed tactical dashboard for analyzing Aviator game predictions across multiple betting platforms (Hollywood, Betway, and LottoStar). This application provides real-time market analysis, strategic betting windows, and historical data tracking.

## Features

### Core Components

**Real-Time Digital Clock**
- LED-style display with Orbitron font
- Shows current time with market analysis status
- Updates every second with tactical aesthetic

**Tactical Radar Animation**
- Animated pink radar with scanning beam effect
- Concentric circles in hot pink and cyan neon
- Rotating beam indicating active scanning
- Glowing center point with cardinal direction markers

**Strategic Prediction Windows**
- **Primary Window (+2):** First betting opportunity with high confidence predictions
- **Secondary Window (+10):** Alternative entry point for improved odds
- Each window displays:
  - Confidence percentage with visual progress bar
  - Predicted multiplier value
  - Active/inactive status with pulse animation
  - Quick action buttons for placing bets

**Historical Data Tracker**
- Platform-specific statistics (Hollywood, Betway, LottoStar)
- Win rate calculations and trending indicators
- Recent results list with timestamps and multipliers
- Manual result entry for tracking game outcomes
- Color-coded results (pink vs. other outcomes)

### Design Philosophy

The application follows a **Cyberpunk Tactical Dashboard** aesthetic:
- **Color Scheme:** Deep navy background with hot pink (#ff006e) and cyan (#00f5ff) neon accents
- **Typography:** Orbitron for headers (futuristic), Inter for body text, JetBrains Mono for data
- **Visual Effects:** Glowing borders, neon shadows, glassmorphic cards, subtle animations
- **Layout:** Asymmetric split design with radar on left, predictions in center, data tracker on right

## How to Use

### Calculate Predictions
1. Click the **CALCULATE** button in the top right
2. The system will analyze market data for 2 seconds
3. Results appear in the Strategic Windows section
4. Confidence levels and multipliers update automatically

### Track Results
1. In the Data Tracker section (right panel), click **+ ADD RESULT**
2. A new result is randomly generated for demonstration
3. Platform statistics update in real-time
4. Results are displayed with timestamps and multiplier values

### Betting Strategy

The application implements a two-window betting strategy:

**If High Multiplier Doesn't Appear at +2:**
- Monitor the Primary Window (+2) for initial opportunity
- If confidence is low or multiplier is unfavorable
- Switch to Secondary Window (+10) for better odds
- The system tracks both windows for optimal entry points

## Technical Stack

- **Frontend:** React 19 with TypeScript
- **Styling:** Tailwind CSS 4 with custom cyberpunk color scheme
- **Fonts:** Google Fonts (Orbitron, Inter, JetBrains Mono)
- **Animations:** CSS keyframes and Canvas API for radar
- **State Management:** React hooks (useState, useEffect)

## Component Structure

```
client/src/
├── pages/
│   └── Home.tsx              # Main dashboard layout
├── components/
│   ├── Radar.tsx             # Animated tactical radar
│   ├── DigitalClock.tsx      # Real-time LED clock
│   ├── PredictionWindow.tsx  # +2 and +10 betting windows
│   └── DataTracker.tsx       # Historical data and statistics
└── index.css                 # Global styles and color scheme
```

## Key Features

### Real-Time Updates
- Clock updates every second
- Radar continuously animates
- Data tracker maintains live statistics
- Predictions update on demand

### Visual Feedback
- Glowing neon effects on active elements
- Pulse animations for alerts
- Smooth transitions and hover effects
- Color-coded data (pink for successful predictions)

### Data Management
- Manual result entry for tracking
- Platform-specific statistics
- Win rate calculations
- Timestamp tracking for all results

## Customization

### Adjust Prediction Confidence
Modify the confidence calculation in `Home.tsx`:
```typescript
const confidence2 = Math.floor(Math.random() * 40) + 60; // 60-100%
```

### Change Color Scheme
Edit the OKLCH color values in `client/src/index.css`:
```css
--primary: oklch(0.65 0.25 320);  /* Hot pink */
--accent: oklch(0.65 0.25 320);   /* Neon accent */
```

### Modify Radar Animation Speed
In `Radar.tsx`, adjust the rotation increment:
```typescript
rotationRef.current = (rotationRef.current + 2) % 360; // Change 2 to faster/slower
```

## Platform Integration

The application is designed to work with:
- **Hollywood** - Aviator betting platform
- **Betway** - Sports betting and gaming
- **LottoStar** - Lottery and gaming platform

Each platform's data is tracked separately with individual statistics and win rates.

## Future Enhancements

- API integration for real-time market data
- Advanced prediction algorithms
- WebSocket support for live updates
- User authentication and profiles
- Betting history export
- Mobile-responsive improvements
- Sound effects for alerts
- Customizable prediction parameters

## System Requirements

- Modern web browser (Chrome, Firefox, Safari, Edge)
- JavaScript enabled
- No external API keys required (demo mode)
- Responsive design supports desktop and tablet viewing

## Notes

- This application is designed for **educational and analysis purposes**
- Predictions are simulated for demonstration
- Always gamble responsibly
- Past performance does not guarantee future results
- Actual betting decisions should be based on personal analysis

## License

MIT License - Feel free to modify and distribute as needed.

---

**AVIATOR PREDICTION BOT v1.0** | Real-Time Market Analysis | Strategic Betting Windows
